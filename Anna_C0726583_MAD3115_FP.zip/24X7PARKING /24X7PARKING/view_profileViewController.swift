//
//  view_profileViewController.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-05.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import UIKit

class view_profileViewController: UIViewController
{
   
    @IBOutlet weak var label_name: UILabel!
    
    @IBOutlet weak var label_last_name: UILabel!
    
    @IBOutlet weak var label_email: UILabel!
    

    @IBOutlet weak var label_contact: UILabel!
    
    @IBOutlet weak var label_plate: UILabel!
    
    
    
    
    func load_data_from_DB()
    {
        let temp_first_name = UserDefaults.standard.value(forKey: "first_name_dat") as? String
        let temp_last_name  = UserDefaults.standard.value(forKey: "last_name_dat") as? String
        let temp_email      = UserDefaults.standard.value(forKey: "email_dat") as? String
        let temp_contact    = UserDefaults.standard.value(forKey: "contact_dat") as? String
        let temp_plate_no   = UserDefaults.standard.value(forKey: "plate_no_dat") as? String
        
        
        
        
        
        label_name.text       =  temp_first_name
        label_last_name.text  =  temp_last_name
        label_email.text      =  temp_email
        label_contact.text    =  temp_contact
        label_plate.text      =  temp_plate_no
        
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        load_data_from_DB()
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

