//
//  SupportCallViewController.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-06.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import UIKit
import MessageUI

class SupportCallViewController: UIViewController, MFMailComposeViewControllerDelegate{
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func btnCallUs(_ sender: Any) {
        let url = URL(string: "tel://+16474482115")
        UIApplication.shared.openURL(url as! URL)
        
    }
    
    
    @IBAction func btnsendMail(_ sender: Any) {
       let mailComposeViewController = configureMailController()
    if MFMailComposeViewController.canSendMail() {
           self.present(mailComposeViewController, animated: true, completion: nil)
            
        }
    else {
        showMailError()
        }
    }
    
    func configureMailController() -> MFMailComposeViewController{
        
        let mailComposeVC = MFMailComposeViewController()
        mailComposeVC.mailComposeDelegate = self
        mailComposeVC.setToRecipients(["nekha1996@gmail.com"])
        mailComposeVC.setSubject("Support")
        mailComposeVC.setMessageBody("Hi Team!\n\nI would like to ask for support regarding following issues..\n", isHTML: false)
        return mailComposeVC
    }
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send mail", message: "Your Device must have active mail",preferredStyle: .alert)
        //sendMailErrorAlert.show()
        let dismiss = UIAlertAction(title: "OK", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    

}
