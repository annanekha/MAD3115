//
//  webpageVC.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-05.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import UIKit

class webpageVC: UIViewController {
    
    
    @IBOutlet weak var mywebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadManual()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadManual(){
        
        let localfp = Bundle.main.url(forResource :"manual", withExtension: "html")
        let myRequest = NSURLRequest(url: localfp!)
        mywebView.loadRequest(myRequest as URLRequest)
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

