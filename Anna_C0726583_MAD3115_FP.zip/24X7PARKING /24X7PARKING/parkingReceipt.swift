//
//  parkingReceipt.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-05.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import UIKit

class parkingReceipt: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource
{
    
    
    
    @IBOutlet weak var lblmins: UILabel!
    @IBOutlet weak var lblhr: UILabel!
    @IBOutlet weak var park_time_label: UILabel!
    @IBOutlet weak var manufaturer_picker: UIPickerView!
    @IBOutlet weak var manu_image: UIImageView!
    @IBOutlet weak var payment_picker: UIPickerView!
    @IBOutlet weak var date_label: UILabel!
    @IBOutlet weak var time_label: UILabel!
    @IBOutlet weak var label_amount: UILabel!
    
    @IBOutlet weak var colortxt: UITextField!
    
    @IBOutlet weak var parkinglottxt: UITextField!
    
    @IBOutlet weak var platetxt: UITextField!
    
    @IBOutlet weak var spottxt: UITextField!
    
    
    @IBOutlet weak var amountlbl: UILabel!
    @IBOutlet weak var timetxt: UILabel!
    
    @IBOutlet weak var datetxt: UILabel!
    
    
    
    @IBAction func savetxt(_ sender: UIButton) {
        displayWelcomeScreen()
        
        
    }
    
  @IBAction func actionbtn(_ sender: UIButton) {
        
        let ParkingSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let ParkingVC = ParkingSB.instantiateViewController(withIdentifier: "ParkingListScreen")
        navigationController?.pushViewController(ParkingVC, animated: true)
        
        
    }
    
    
    
    func displayWelcomeScreen(){
        
        let myreg = NSMutableDictionary()
        myreg["car color"] = self.colortxt.text
        myreg["parking lot"] = self.parkinglottxt.text
        myreg["plate number"] = self.platetxt.text
        myreg["parking spot"] = self.spottxt.text
        myreg["Amount"] = self.amountlbl.text
        myreg["Time"] = self.timetxt.text
        myreg["Date"] = self.datetxt.text
        if let plistPath = Bundle.main.path(forResource: "recipt", ofType: "plist"){
            let regplist = NSMutableArray(contentsOfFile: plistPath)
            regplist?.add(myreg)
            if (regplist?.write(toFile: plistPath, atomically: true))!{
                print("parking Recipt : \(String(describing: regplist))")
            }
            
        }else{
            print("Unable to locate plist file")
        }
        
        
       // let loginsb : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        //let loginvc = loginsb.instantiateViewController(withIdentifier: "MainScreen")
        
      //  navigationController?.pushViewController(loginvc, animated: true)
    }
    
    
    
    let manufacturers = ["Audi","BMW","Ford","Lamborghini","Hyundai","Volkswagen"]
    let manufacture_images  = ["audi.png","BMW.png","ford.png","lambo.png","hyundai.png","volks.png"]
    let payment_method  = ["Credit","Debit"]
    var parked_time : String = " "
    
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //add data in picker
        self.manufaturer_picker.delegate = self
        self.manufaturer_picker.dataSource = self
        self.payment_picker.delegate = self
        self.payment_picker.dataSource = self
        park_time_label.text = "20 :"
        lblhr.text = "00 :"
        lblmins.text = "05"
        
        
        // pulling current date and time.
        let date = Date()
        let formatter = DateFormatter()
        let time_formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        time_formatter.dateFormat = "HH:mm:ss"
        let result = formatter.string(from: date)
        let current_time = time_formatter.string(from: date)
        date_label.text = result
        time_label.text = current_time
        label_amount.text = (String)(Int(arc4random_uniform(4)))
    }
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        var t_count = 0
        if pickerView == manufaturer_picker
        {
            t_count = self.manufacturers.count
            
        } else
            
            if pickerView == payment_picker
            {
                //pickerView2
                t_count = self.payment_method.count
        }
        
        return t_count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> (String?)
        
    {
        var t_string = " "
        var t_imgname : String = ""
        if pickerView == manufaturer_picker
        {
            t_string = self.manufacturers[row]
            manu_image.image = UIImage(named: manufacture_images[row])   // loading the image  // storing product number
            
        } else if pickerView == payment_picker
        {
            //pickerView2
            t_string = self.payment_method[row]
            
            
        }
        
        return t_string
        
    }
    
}

