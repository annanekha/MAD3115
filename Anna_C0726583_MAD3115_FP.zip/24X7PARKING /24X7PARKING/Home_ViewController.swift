//
//  Home_ViewController.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-05.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import UIKit

class Home_ViewController: UIViewController {
    
    var flag = false
    
    
    
    
    @IBAction func btn_logout(_ sender: UIButton) {
        
        self.performSegue(withIdentifier: "back_to_login_segue", sender: self)
        
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewDidAppear(_ animated: Bool)                   // code to create a segue directly to logn screen
        
    {
//        if (flag == false)
//        {
//            self.performSegue(withIdentifier: "login_segue", sender: self)
//        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

