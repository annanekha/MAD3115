//
//  supportViewController.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-06.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

//
//import UIKit
//import MessageUI
//
//class supportViewController: UITableViewController, MFMailComposeViewControllerDelegate{
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Uncomment the following line to preserve selection between presentations
//        // self.clearsSelectionOnViewWillAppear = false
//        
//        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//        // self.navigationItem.rightBarButtonItem = self.editButtonItem
//    }
//    
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print("selected row = \(indexPath.description)")
//        if indexPath.section == 0 && indexPath.row == 0
//        {
//            print("Rate Us row tapped")
//        }
//        if indexPath.section == 0 && indexPath.row == 1
//        {
//            print("Need Support row tapped")
//        }
//        
//        let mailComposeViewController = configureMailComposeViewController()
//        if !MFMailComposeViewController.canSendMail() {
//            self.present(mailComposeViewController, animated: true, completion: nil)
//        }
//        else{
//            self.sendMailErrorAlert()
//        }
//    }
//    
//    func configureMailComposeViewController() -> MFMailComposeViewController {
//        let mailComposeVC = MFMailComposeViewController()
//        mailComposeVC.mailComposeDelegate = self
//        mailComposeVC.setToRecipients(["nekha1996@gmail.com"])
//        mailComposeVC.setSubject("App Support")
//        mailComposeVC.setMessageBody("Hi Team!\n\nI would like to ask for support regarding following issues..\n", isHTML: false)
//        
//        return mailComposeVC
//    }
//    
//    func sendMailErrorAlert() {
//        let smErrorAlert = UIAlertController(title: "Could not send mail", message : "Your device could not send email. please try again later" , preferredStyle: .alert  )
//        
//        
//        smErrorAlert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
//        
//        self.present(smErrorAlert, animated: true, completion: nil)
//    }
//    
//    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
//        switch result.rawValue {
//        case MFMailComposeResult.rawValue:
//            print("Cancelled Mail")
//        case MFMailComposeResult.rawValue :
//            print("Mail Sent")
//        default:
//            break
//        }
//        //        self.dismiss(animated : true, completion: nil)
//    }
//    
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//    
//}

