//
//  Edit_profile_VC.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-05.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import UIKit

class Edit_profile_VC: UIViewController
    
{
    var home_obj = Home_ViewController()
    
    @IBOutlet weak var First_name: UITextField!
    
    @IBOutlet weak var Last_name: UITextField!
    
    @IBOutlet weak var e_mail: UITextField!
    
    @IBOutlet weak var contact_no: UITextField!
    
    @IBOutlet weak var plate_no: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    
    // function to update and save user profile data
    func update_user_profile_data()
    {
        UserDefaults.standard.set(First_name.text, forKey: "first_name_dat")
        UserDefaults.standard.set(Last_name.text, forKey: "last_name_dat")
        UserDefaults.standard.set(e_mail.text, forKey: "email_dat")
        UserDefaults.standard.set(password.text, forKey: "password_dat")
        UserDefaults.standard.set(contact_no.text,forKey: "contact_dat")
        UserDefaults.standard.set(plate_no.text, forKey: "plate_no_dat")
        
        
    }
    
    
    
    
    // code to perform cancel registration
    @IBAction func cancel_button(_ sender: Any)
    {
        
        self.performSegue(withIdentifier: "back_home_update_ok", sender: self)
    }
    
    // code to perform updation of user profile
    @IBAction func ok_button(_ sender: Any)
    {
        // validation for null values.
        
        if (First_name.text == "") || (Last_name.text == "") || (e_mail.text == "") || (password.text == "") || (contact_no.text == "") || (plate_no.text == "")
        {
            let infoAlert_error = UIAlertController(title: "User Data missing !", message: "Please fill all the fields ! !", preferredStyle: .alert)
            
            infoAlert_error.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            
            self.present(infoAlert_error, animated: true, completion: nil)
        }
            
        else
        {
            update_user_profile_data()
            
            
            let infoAlert_success = UIAlertController(title: "Update Sucessful !", message: nil, preferredStyle: .alert)
            
            infoAlert_success.addAction(UIAlertAction(title: "Okay", style: .default, handler: {(action:UIAlertAction) in
                self.performSegue(withIdentifier: "back_home_update_ok", sender: self)
            }))
            self.present(infoAlert_success, animated: true, completion: nil)
            
        }
    }
    
    // function to display the current data in the edit screen
    func show_current_profile()
    {
        First_name.text  = UserDefaults.standard.value(forKey: "first_name_dat") as? String
        Last_name.text   = UserDefaults.standard.value(forKey: "last_name_dat") as? String
        e_mail.text      = UserDefaults.standard.value(forKey: "email_dat") as? String
        password.text    = UserDefaults.standard.value(forKey: "password_dat") as? String
        contact_no.text  = UserDefaults.standard.value(forKey: "contact_dat") as? String
        plate_no.text    = UserDefaults.standard.value(forKey: "plate_no_dat") as? String
        
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        show_current_profile()          // show the current profile details.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
//    {
//        
//        let DestViewControl : Home_ViewController = segue.destination as! Home_ViewController
//        DestViewControl.flag = true
//      
//        
//    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

