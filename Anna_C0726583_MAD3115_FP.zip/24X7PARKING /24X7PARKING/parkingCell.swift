//
//  parkingCell.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-07.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import Foundation

import UIKit

class ParkingCell: UITableViewCell {
    
    
    
    @IBOutlet weak var lblcolor: UILabel!
    
    @IBOutlet weak var lbldate: UILabel!
    
    @IBOutlet weak var lblplate: UILabel!
    
    @IBOutlet weak var lblplot: UILabel!
    
    
    @IBOutlet weak var lblspot: UILabel!
    
    @IBOutlet weak var lbltime: UILabel!
    
    @IBOutlet weak var lblamount: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
