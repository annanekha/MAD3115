//
//  counterclock.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-05.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import UIKit
class counterclock: UIViewController {
    
    @IBOutlet weak var second_label: UILabel!
    
    
    var countdownTimer: Timer!
    var timer = Timer()
    var intCounter : Int = 0
    
    override func viewDidLoad()
        
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCountdown), userInfo: nil, repeats: true)
        
        
    }
    
    
    
    
    @objc func updateCountdown()
    {
        intCounter += 1
        
        //Set counter in UILabel
        second_label.text! = String(format: "%02d:%02d:%02d", intCounter / 3600, (intCounter % 3600) / 60, (intCounter % 3600) % 60)
    }
    
    
    // finish button to finish parking and proceed with billling.
    
    @IBAction func finish_button(_ sender: Any)
    {
        timer.invalidate()
        intCounter = 0
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var DestViewControl : parkingReceipt = segue.destination as! parkingReceipt
        //        DestViewControl.flag = true
        DestViewControl.parked_time = second_label.text!
    }
    
}

