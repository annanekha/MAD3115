//
//  RegisterViewController.swift
//  24X7PARKING
//
//  Created by Anna Nekha Shabu on 2018-03-05.
//  Copyright © 2018 MightyDevelopers. All rights reserved.
//

import Foundation
import UIKit

class RegisterViewController: UIViewController
{
   
    @IBOutlet weak var First_name: UITextField!
    @IBOutlet weak var Last_name: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var contact: UITextField!
    
    @IBOutlet weak var car_plate_no: UITextField!
    
    var F_name = ""
    var L_name = ""
    var val_email = ""
    var val_password = ""
    var val_contact = ""
    var val_car_plate_no = ""
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func save_user_reg_data()
    {
        UserDefaults.standard.set(F_name, forKey: "first_name_dat")
        UserDefaults.standard.set(L_name, forKey: "last_name_dat")
        UserDefaults.standard.set(val_email, forKey: "email_dat")
        UserDefaults.standard.set(val_password, forKey: "password_dat")
        UserDefaults.standard.set(val_contact,forKey: "contact_dat")
        UserDefaults.standard.set(val_car_plate_no, forKey: "plate_no_dat")
        
        
    }
    
    // function to trigger registration process.
    
//    @IBAction func button_register(_ sender: UIButton) {
//    }
    
    
    @IBAction func button_register(_ sender: Any)
        
    {
        F_name = (First_name.text)!
        L_name = (Last_name.text)!
        val_email = (email.text)!
        val_password = (password.text)!
        val_contact = (contact.text)!
        val_car_plate_no = (car_plate_no.text)!
        
        
        if (First_name.text == "") || (Last_name.text == "") || (email.text == "") || (password.text == "") || (contact.text == "") || (car_plate_no.text == "")
        {
            let infoAlert_error = UIAlertController(title: "User Data missing !", message: "Please fill all the fields ! !", preferredStyle: .alert)
            
            infoAlert_error.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            
            self.present(infoAlert_error, animated: true, completion: nil)
        }
            
        else
        {
            save_user_reg_data()
            
            let infoAlert_success = UIAlertController(title: "Registration Sucessful", message: "You are a new user", preferredStyle: .alert)
            
            
            infoAlert_success.addAction(UIAlertAction(title: "Okay", style: .default, handler: {(action:UIAlertAction) in
                self.navigationController?.popViewController(animated: true)
                
                
                self.performSegue(withIdentifier: "login_segue", sender: self)
                
                
            }))
            self.present(infoAlert_success, animated: true, completion: nil)
        }
        
        
    }
    
    
}

